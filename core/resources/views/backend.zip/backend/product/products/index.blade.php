@extends('backend.layouts.app')

@section('content')
    @php
        CoreComponentRepository::instantiateShopRepository();
        CoreComponentRepository::initializeCache();

        $pageTitle = translate('All products');
        $pageDescription = translate('Manage catalog views, stock, publishing, and merchandising from a denser command workspace.');
        $scopeLabel = translate('All catalog');

        if ($seller_type == 'seller') {
            $scopeLabel = translate('Seller catalog');
        } elseif ($seller_type == 'admin') {
            $scopeLabel = translate('In-house catalog');
        }
    @endphp

    <div class="admin-page-header">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <div class="admin-page-eyebrow">{{ translate('Catalog operations') }}</div>
                <h1 class="admin-page-title">{{ $pageTitle }}</h1>
                <p class="admin-page-description">{{ $pageDescription }}</p>
                @if (isset($back_to) && $back_to == 'brands')
                    <a class="admin-inline-link" href="{{ route('brands.index') }}"><i class="las la-angle-left"></i> {{ translate('Back to Brands') }}</a>
                @elseif (isset($back_to) && $back_to == 'categories')
                    <a class="admin-inline-link" href="{{ route('categories.index') }}"><i class="las la-angle-left"></i> {{ translate('Back to Categories') }}</a>
                @endif
            </div>
            <div class="col-lg-4 mt-4 mt-lg-0">
                <div class="admin-header-actions">
                    <span class="admin-page-stat">
                        <span>{{ translate('Views') }}</span>
                        <strong>{{ count($product_types) }}</strong>
                    </span>
                    <span class="admin-page-stat">
                        <span>{{ translate('Scope') }}</span>
                        <strong>{{ $scopeLabel }}</strong>
                    </span>
                    @if ($seller_type != 'seller' && auth()->user()->can('add_new_product'))
                        <a href="{{ route('products.create') }}" class="btn btn-info">
                            <span>{{ translate('Add New Product') }}</span>
                        </a>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="admin-stats-grid admin-stats-grid-tight">
        <div class="admin-stat-card">
            <div class="admin-stat-label">{{ translate('View tabs') }}</div>
            <div class="admin-stat-value">{{ count($product_types) }}</div>
            <div class="admin-stat-meta">{{ translate('Available catalog slices for quick switching.') }}</div>
        </div>
        <div class="admin-stat-card">
            <div class="admin-stat-label">{{ translate('Seller scope') }}</div>
            <div class="admin-stat-value">{{ $scopeLabel }}</div>
            <div class="admin-stat-meta">{{ translate('Current catalog ownership context for this workspace.') }}</div>
        </div>
        <div class="admin-stat-card">
            <div class="admin-stat-label">{{ translate('Brand filter') }}</div>
            <div class="admin-stat-value">{{ !empty($brand_id) ? translate('Scoped') : translate('All') }}</div>
            <div class="admin-stat-meta">{{ translate('Catalog can be narrowed to a specific brand when needed.') }}</div>
        </div>
        <div class="admin-stat-card">
            <div class="admin-stat-label">{{ translate('Category filter') }}</div>
            <div class="admin-stat-value">{{ !empty($category_id) ? translate('Scoped') : translate('All') }}</div>
            <div class="admin-stat-meta">{{ translate('Current category context for merchandising review.') }}</div>
        </div>
    </div>

    <div class="card">
        <form id="sort_products" action="" method="GET">
            <div class="card-header">
                <div class="d-flex align-items-start justify-content-between flex-wrap w-100">
                    <div class="admin-section-intro mb-0">
                        <span class="eyebrow">{{ translate('Command view') }}</span>
                        <h2>{{ translate('Switch product queues and take batch actions quickly') }}</h2>
                        <p>{{ translate('Use the controls below to change catalog views, narrow the list, and trigger merchandising actions without leaving the page.') }}</p>
                    </div>
                    @if ($seller_type != 'seller' && auth()->user()->can('add_new_product'))
                        <a href="{{ route('products.create') }}" class="add-new-btn">
                            <span class="label-text">{{ translate('Add New Product') }}</span>
                            <span class="plus-icon-container">
                                <svg id="plus-icon" xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12">
                                    <path
                                        d="M141.874-812.13a.706.706,0,0,1-.515-.21.7.7,0,0,1-.212-.514V-817.4h-4.553a.7.7,0,0,1-.514-.209.694.694,0,0,1-.21-.511.706.706,0,0,1,.21-.515.7.7,0,0,1,.514-.212h4.549v-4.557a.7.7,0,0,1,.209-.514.694.694,0,0,1,.511-.21.706.706,0,0,1,.515.21.7.7,0,0,1,.212.514v4.553h4.557a.7.7,0,0,1,.514.208.694.694,0,0,1,.21.511.706.706,0,0,1-.21.515.7.7,0,0,1-.514.212h-4.553v4.553a.7.7,0,0,1-.209.514A.694.694,0,0,1,141.874-812.13Z"
                                        transform="translate(-135.87 824.13)" fill="#fff" />
                                </svg>
                            </span>
                        </a>
                    @endif
                </div>
            </div>

            <div class="card-body">
                <div class="table-nav-tabs mb-4">
                    <div class="table-tabs-container flex-grow-1">
                        <ul class="nav nav-tabs border-0" id="myTab" role="tablist">
                            @foreach ($product_types as $product_type)
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link px-0 pb-15px fs-14 fw-500 {{ $loop->first ? 'active' : '' }}"
                                        data-toggle="tab" role="tab" aria-selected="{{ $loop->first ? 'true' : 'false' }}"
                                        id="{{ Str::slug($product_type) }}-tab"
                                        onclick="changeTab(this, '{{ Str::slug($product_type) }}')" aria-controls="{{ Str::slug($product_type) }}">
                                        {{ translate($product_type) }}
                                    </button>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>

                <div class="tab-filter-bar">
                    <div class="admin-command-bar admin-command-bar-products">
                        <div class="admin-command-grow">
                            <div class="input-group mb-0 admin-search-input">
                                <div class="input-group-prepend">
                                    <span class="input-group-text border-0 bg-transparent px-0" id="search">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16.001" height="16" viewBox="0 0 16.001 16">
                                            <path
                                                d="M8.248,14.642a6.394,6.394,0,1,1,6.394-6.394A6.4,6.4,0,0,1,8.248,14.642Zm0-11.509a5.115,5.115,0,1,0,5.115,5.115A5.121,5.121,0,0,0,8.248,3.133Z"
                                                transform="translate(-1.854 -1.854)" fill="#a5a5b8" />
                                            <path
                                                d="M23.011,23.651a.637.637,0,0,1-.452-.187l-4.92-4.92a.639.639,0,0,1,.9-.9l4.92,4.92a.639.639,0,0,1-.452,1.091Z"
                                                transform="translate(-7.651 -7.651)" fill="#a5a5b8" />
                                        </svg>
                                    </span>
                                </div>
                                <input type="text" class="form-control form-control-sm border-0 px-2 bg-transparent"
                                    id="search_input" name="search" placeholder="{{ translate('Search products, SKU, or title') }}">
                            </div>
                        </div>

                        <div class="admin-command-narrow">
                            <div class="dropdown w-100">
                                <button class="btn btn-light dropdown-toggle w-100 justify-content-between" type="button" data-toggle="dropdown">
                                    {{ translate('Bulk Action') }}
                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    @can('product_edit')
                                        <a class="dropdown-item confirm-alert text-secondary fs-14 fw-500 hov-bg-light hov-text-blue"
                                            href="javascript:void(0)" id="bulk-publish-option" onclick="bulkPublish()">
                                            {{ translate('Publish') }}</a>
                                        <a class="dropdown-item text-secondary fs-14 fw-500 hov-bg-light hov-text-blue" id="bulk-featured-option" onclick="bulkFeatured()"
                                            href="javascript:void(0)">
                                            {{ translate('Mark Featured') }}</a>
                                        <a class="dropdown-item text-secondary fs-14 fw-500 hov-bg-light hov-text-blue" id="bulk-td-option" onclick="bulkProductTodaysDeal()"
                                            href="javascript:void(0)">
                                            {{ translate('Mark Todays Deal') }}</a>
                                    @endcan
                                    @can('product_delete')
                                        <a class="dropdown-item confirm-alert text-danger fs-14 fw-500 hov-bg-light hov-text-blue"
                                            href="javascript:void(0)" onclick="bulkDelete()">
                                            {{ translate('Delete') }}</a>
                                    @endcan
                                </div>
                            </div>
                        </div>

                        @if ($seller_type == 'seller')
                            <div class="admin-command-narrow">
                                <select class="form-control aiz-selectpicker mb-2 mb-md-0" id="user_id" name="user_id" onchange="sort_products()">
                                    <option value="" class="hov-bg-light text-secondary fs-14 fw-40">{{ translate('All Sellers') }}</option>
                                    @foreach (App\Models\User::where('user_type', '=', 'seller')->get() as $key => $seller)
                                        <option class="hov-bg-light text-secondary fs-14 fw-40" value="{{ $seller->id }}">
                                            {{ $seller->shop?->name }} ({{ $seller->name }})
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        @endif

                        <div class="admin-command-narrow">
                            <div class="dropdown w-100">
                                <button class="btn btn-light w-100 d-flex justify-content-between align-items-center dropdown-toggle"
                                    type="button" id="filterMenu" data-toggle="dropdown" aria-haspopup="true"
                                    aria-expanded="false">
                                    <span>{{ translate('Filter') }}</span>
                                    <span class="dropdown-toggle-icon"></span>
                                </button>

                                <div class="dropdown-menu py-3 w-100" aria-labelledby="filterMenu">
                                    <div class="form-check hover-bg-light py-2 d-flex align-items-center">
                                        <input class="input-check" type="checkbox" id="all">
                                        <label class="form-check-label fs-14 px-2" for="all">All</label>
                                    </div>
                                    <div class="form-check hover-bg-light py-2 d-flex align-items-center">
                                        <input class="input-check" type="checkbox" id="all-publish">
                                        <label class="form-check-label fs-14 px-2" for="all-publish">All Published</label>
                                    </div>
                                    <div class="form-check hover-bg-light py-2 d-flex align-items-center">
                                        <input class="input-check" type="checkbox" id="all-discount">
                                        <label class="form-check-label fs-14 px-2" for="all-discount">All Discounted</label>
                                    </div>
                                    <div class="form-check hover-bg-light py-2 d-flex align-items-center">
                                        <input class="input-check" type="checkbox" id="low-stock">
                                        <label class="form-check-label fs-14 px-2" for="low-stock">Low Stock</label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="admin-command-narrow">
                            <select class="form-control aiz-selectpicker mb-2 mb-md-0" name="type" id="type" onchange="sort_products()">
                                <option value="" class="hov-text-light text-white fs-14 fw-400">Sort</option>
                                <option value="rating,desc" class="hov-bg-light text-secondary fs-14 fw-40"
                                    @isset($col_name, $query) @if ($col_name == 'rating' && $query == 'desc') selected @endif @endisset>
                                    {{ translate('Rating (High > Low)') }}</option>
                                <option value="rating,asc" class="hov-bg-light text-secondary fs-14 fw-40"
                                    @isset($col_name, $query) @if ($col_name == 'rating' && $query == 'asc') selected @endif @endisset>
                                    {{ translate('Rating (Low > High)') }}</option>
                                <option value="num_of_sale,desc" class="hov-bg-light text-secondary fs-14 fw-40"
                                    @isset($col_name, $query) @if ($col_name == 'num_of_sale' && $query == 'desc') selected @endif @endisset>
                                    {{ translate('Num of Sale (High > Low)') }}</option>
                                <option value="num_of_sale,asc" class="hov-bg-light text-secondary fs-14 fw-40"
                                    @isset($col_name, $query) @if ($col_name == 'num_of_sale' && $query == 'asc') selected @endif @endisset>
                                    {{ translate('Num of Sale (Low > High)') }}</option>
                                <option value="unit_price,desc" class="hov-bg-light text-secondary fs-14 fw-40"
                                    @isset($col_name, $query) @if ($col_name == 'unit_price' && $query == 'desc') selected @endif @endisset>
                                    {{ translate('Base Price (High > Low)') }}</option>
                                <option value="unit_price,asc" class="hov-bg-light text-secondary fs-14 fw-40"
                                    @isset($col_name, $query) @if ($col_name == 'unit_price' && $query == 'asc') selected @endif @endisset>
                                    {{ translate('Base Price (Low > High)') }}</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="tab-content filter-tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="tab-content">
                    </div>
                </div>
            </div>
        </form>
    </div>
@endsection

@section('modal')
    @include('modals.loading_modal')

    <div id="rightOffcanvas" class="right-offcanvas-lg position-fixed top-0 fullscreen bg-white py-20px z-1045">
    </div>
    <div id="rightOffcanvasOverlay" class="position-fixed top-0 left-0 h-100 w-100"></div>
@endsection

@section('script')
    <script type="text/javascript">
        let currentTab = '{{ Str::slug($product_types[0] ?? '') }}';
        let searchTimer;
        let seller_type = '{{ $seller_type }}';
        let selected_filter = [];
        let brand_id = '{{ $brand_id ?? '' }}';
        let category_id = '{{ $category_id ?? '' }}';

        $(document).on("change", ".check-all", function() {
            if (this.checked) {
                $('.check-one:checkbox').each(function() {
                    this.checked = true;
                });
            } else {
                $('.check-one:checkbox').each(function() {
                    this.checked = false;
                });
            }
        });

        $(document).ready(function() {
        });

        function update_todays_deal(el) {
            if ('{{ env('DEMO_MODE') }}' == 'On') {
                AIZ.plugins.notify('info', '{{ translate('Data can not change in demo mode.') }}');
                return;
            }

            var status = el.checked ? 1 : 0;
            $.post('{{ route('products.todays_deal') }}', {
                _token: '{{ csrf_token() }}',
                id: el.value,
                status: status
            }, function(data) {
                if (data == 1) {
                    AIZ.plugins.notify('success', '{{ translate('Todays Deal updated successfully') }}');
                } else {
                    AIZ.plugins.notify('danger', '{{ translate('Something went wrong') }}');
                }
            });
        }

        function update_published(el) {
            if ('{{ env('DEMO_MODE') }}' == 'On') {
                AIZ.plugins.notify('info', '{{ translate('Data can not change in demo mode.') }}');
                return;
            }

            var status = el.checked ? 1 : 0;
            $.post('{{ route('products.published') }}', {
                _token: '{{ csrf_token() }}',
                id: el.value,
                status: status
            }, function(data) {
                if (data == 1) {
                    AIZ.plugins.notify('success', '{{ translate('Published products updated successfully') }}');
                } else if (data == 3) {
                    AIZ.plugins.notify('danger', '{{ translate('GST verification is pending for this account.') }}');
                } else if (data == 4) {
                    AIZ.plugins.notify('warning', '{{ translate('Please assign GST details') }}');
                } else {
                    AIZ.plugins.notify('danger', '{{ translate('Something went wrong') }}');
                }
            });
        }

        function update_approved(el) {
            if ('{{ env('DEMO_MODE') }}' == 'On') {
                AIZ.plugins.notify('info', '{{ translate('Data can not change in demo mode.') }}');
                return;
            }

            var approved = el.checked ? 1 : 0;
            $.post('{{ route('products.approved') }}', {
                _token: '{{ csrf_token() }}',
                id: el.value,
                approved: approved
            }, function(data) {
                if (data == 1) {
                    AIZ.plugins.notify('success', '{{ translate('Product approval update successfully') }}');
                } else {
                    AIZ.plugins.notify('danger', '{{ translate('Something went wrong') }}');
                }
            });
        }

        function update_featured(el) {
            if ('{{ env('DEMO_MODE') }}' == 'On') {
                AIZ.plugins.notify('info', '{{ translate('Data can not change in demo mode.') }}');
                return;
            }

            var status = el.checked ? 1 : 0;
            $.post('{{ route('products.featured') }}', {
                _token: '{{ csrf_token() }}',
                id: el.value,
                status: status
            }, function(data) {
                if (data == 1) {
                    AIZ.plugins.notify('success', '{{ translate('Featured products updated successfully') }}');
                } else {
                    AIZ.plugins.notify('danger', '{{ translate('Something went wrong') }}');
                }
            });
        }

        function single_delete(productId) {
            $.ajax({
                url: "{{ route('products.destroy', ':id') }}".replace(':id', productId),
                type: 'GET',
                success: function(response) {
                    if (response == 1) {
                        AIZ.plugins.notify('success', '{{ translate('Selected item deleted successfully') }}');
                        hideBulkActionModal();
                        getProducts(currentTab);
                    }
                }
            });
        }

        function bulk_delete() {
            var data = new FormData($('#sort_products')[0]);
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: "{{ route('bulk-product-delete') }}",
                type: 'POST',
                data: data,
                cache: false,
                contentType: false,
                processData: false,
                success: function(response) {
                    if (response == 1) {
                        AIZ.plugins.notify('success', '{{ translate('Selected items deleted successfully') }}');
                        hideBulkActionModal();
                        getProducts(currentTab);
                    }
                }
            });
        }

        function bulk_publish() {
            var data = new FormData($('#sort_products')[0]);
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: "{{ route('bulk-product-publish') }}",
                type: 'POST',
                data: data,
                cache: false,
                contentType: false,
                processData: false,
                success: function(response) {
                    if (response == 1) {
                        AIZ.plugins.notify('success', '{{ translate('Selected items Published successfully') }}');
                        hideBulkActionModal();
                        getProducts(currentTab);
                    }
                },
                error: function() {
                    AIZ.plugins.notify('danger', 'Something went wrong');
                }
            });
        }

        function bulk_feature() {
            var data = new FormData($('#sort_products')[0]);
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: "{{ route('bulk-product-featured') }}",
                type: 'POST',
                data: data,
                cache: false,
                contentType: false,
                processData: false,
                success: function(response) {
                    if (response == 1) {
                        AIZ.plugins.notify('success', '{{ translate('Selected items added in featured successfully') }}');
                        hideBulkActionModal();
                        getProducts(currentTab);
                    }
                },
                error: function() {
                    AIZ.plugins.notify('danger', 'Something went wrong');
                }
            });
        }

        function bulk_todays_deal() {
            var data = new FormData($('#sort_products')[0]);
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: "{{ route('bulk-product-todays-deal') }}",
                type: 'POST',
                data: data,
                cache: false,
                contentType: false,
                processData: false,
                success: function(response) {
                    if (response == 1) {
                        AIZ.plugins.notify('success', '{{ translate("Selected products have been marked as Todays Deals.") }}');
                        hideBulkActionModal();
                        getProducts(currentTab);
                    }
                }
            });
        }

        var duplicateProductUrl = "{{ route('products.duplicate', ':id') }}";

        function singleDelete(productId) {
            showBulkActionModal();
            $('#confirmation-title').text('{{ translate('Delete Confirmation') }}');
            $('#confirmation-question').text('{{ translate('Are you sure you want to delete the selected product?') }}');
            $('#impact-message').text('{{ translate('This action cannot be undone. Once deleted, the product will be permanently removed.') }}');
            $('#conform-yes-btn').attr("onclick", "single_delete(" + productId + ")");
            $('.confirmation-icon').addClass('d-none');
            $('#delete-confirm-icon').removeClass('d-none');
        }

        function bulkDelete() {
            if ($('.check-one:checked').length == 0) {
                AIZ.plugins.notify('danger', '{{ translate('Please select at least one item') }}');
                return;
            }
            showBulkActionModal();
            $('#confirmation-title').text('{{ translate('Delete Confirmation') }}');
            $('#confirmation-question').text('{{ translate('Are you sure you want to delete the selected products?') }}');
            $('#impact-message').text('{{ translate('This action cannot be undone. Once deleted, the products will be permanently removed.') }}');
            $('#conform-yes-btn').attr("onclick", "bulk_delete()");
            $('.confirmation-icon').addClass('d-none');
            $('#delete-confirm-icon').removeClass('d-none');
        }

        function bulkPublish() {
            if ($('.check-one:checked').length == 0) {
                AIZ.plugins.notify('danger', '{{ translate('Please select at least one item') }}');
                return;
            }
            showBulkActionModal();
            $('#confirmation-title').text('{{ translate('Publish Confirmation') }}');
            $('#confirmation-question').text('{{ translate('Are you sure you want to publish the selected products?') }}');
            $('#impact-message').text('{{ translate('Products already published will be skipped.') }}');
            $('#conform-yes-btn').attr("onclick", "bulk_publish()");
            $('.confirmation-icon').addClass('d-none');
            $('#publish-confirm-icon').removeClass('d-none');
        }

        function bulkProductTodaysDeal() {
            if ($('.check-one:checked').length == 0) {
                AIZ.plugins.notify('danger', '{{ translate('Please select at least one item') }}');
                return;
            }
            showBulkActionModal();
            $('#confirmation-title').text('{{ translate('Todays Deal Confirmation') }}');
            $('#confirmation-question').text('{{ translate('Are you sure you want to make the selected products Todays Deals?') }}');
            $('#impact-message').text('{{ translate('Products already marked as Todays Deals will be skipped.') }}');
            $('#conform-yes-btn').attr("onclick", "bulk_todays_deal()");
            $('.confirmation-icon').addClass('d-none');
            $('#todays-confirm-icon').removeClass('d-none');
        }

        function bulkFeatured() {
            if ($('.check-one:checked').length == 0) {
                AIZ.plugins.notify('danger', '{{ translate('Please select at least one item') }}');
                return;
            }
            showBulkActionModal();
            $('#confirmation-title').text('{{ translate('Feature Confirmation') }}');
            $('#confirmation-question').text('{{ translate('Are you sure you want to mark the selected products as featured ?') }}');
            $('#impact-message').text('{{ translate('Products already marked as featured will be skipped.') }}');
            $('#conform-yes-btn').attr("onclick", "bulk_feature()");
            $('.confirmation-icon').addClass('d-none');
            $('#feature-confirm-icon').removeClass('d-none');
        }

        function getProducts(slug, page = 1) {
            var type = $('#type').val();
            var user_id = $('#user_id').val();
            currentTab = slug;
            slug = slug.replace(/-/g, '_');
            let keyword = $('#search_input').val();
            $('#tab-content').html('<div class="footable-loader mt-5"><span class="fooicon fooicon-loader"></span></div>');
            $.ajax({
                url: `{{ route('products.filter') }}?page=${page}`,
                method: 'GET',
                data: {
                    type: type,
                    product_type: slug,
                    search: keyword,
                    seller_type: seller_type,
                    selected_filter: selected_filter,
                    user_id: user_id,
                    brand_id: brand_id,
                    category_id: category_id
                },
                success: function(response) {
                    $('#tab-content').html(response.html);
                    initFooTable();
                },
                error: function() {
                    $('#tab-content').html('<div class="text-danger p-4">{{ translate("Failed to load data.") }}</div>');
                }
            });
        }

        function changeTab(button, statusSlug) {
            document.querySelectorAll('#myTab .nav-link').forEach(el => el.classList.remove('active'));
            button.classList.add('active');
            if (statusSlug == 'inhouse-products') {
                seller_type = 'admin';
            } else if (statusSlug == 'seller-products') {
                seller_type = 'seller';
            } else {
                seller_type = '{{ $seller_type }}';
            }

            if (statusSlug === 'drafts') {
                $('#bulk-publish-option, #bulk-featured-option, #bulk-td-option').hide();
            } else {
                $('#bulk-publish-option, #bulk-featured-option, #bulk-td-option').show();
            }

            getProducts(statusSlug);
        }

        document.addEventListener('DOMContentLoaded', function() {
            getProducts(currentTab);
        });

        function sort_products(el) {
            getProducts(currentTab);
        }

        $('#search_input').on('keyup', function() {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(function() {
                getProducts(currentTab);
            }, 500);
        });

        $('.input-check').on('change', function() {
            if (this.id === 'all') {
                if ($(this).is(':checked')) {
                    $('.input-check').prop('checked', true);
                } else {
                    $('.input-check').prop('checked', false);
                }
            } else if (!$(this).is(':checked')) {
                $('#all').prop('checked', false);
            }

            selected_filter = [];
            $('.input-check:checked').each(function() {
                if (this.id !== 'all') {
                    selected_filter.push(this.id);
                }
            });
            getProducts(currentTab);
        });

        $(document).on('click', '.pagination a', function(e) {
            e.preventDefault();
            const page = $(this).attr('href').split('page=')[1];
            getProducts(currentTab, page);
        });

        const rightOffcanvas = document.getElementById('rightOffcanvas');
        const overlay = document.getElementById('rightOffcanvasOverlay');

        function openRightcanvas(id, name) {
            rightOffcanvas.classList.add('active');
            overlay.classList.add('active');
            document.body.classList.add('body-no-scroll');
            rightOffcanvas.innerHTML = '';

            $.ajax({
                type: "GET",
                url: "{{ route('stock.show', '') }}/" + id,
                success: function(data) {
                    rightOffcanvas.innerHTML = data;
                },
                error: function() {
                    rightOffcanvas.innerHTML = '<p class="text-danger">{{ translate("Failed to load stock data") }}</p>';
                }
            });
        }

        function closeRightcanvas() {
            rightOffcanvas.classList.remove('active');
            overlay.classList.remove('active');
            document.body.classList.remove('body-no-scroll');
        }

        function closeOffcanvas() {
            closeRightcanvas();
        }

        if (overlay) {
            overlay.addEventListener('click', closeRightcanvas);
        }

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') closeRightcanvas();
        });

        function enableInputField() {
            $('.stock-input').removeClass('d-none');
            $('.stock-input').each(function() {
                $(this).attr('disabled', false);
            });
            $('span#stock-quantity').addClass('d-none');
            $('#offcanvas-btn').removeClass('d-none');
        }

        function disableInputField() {
            $('.stock-input').addClass('d-none');
            $('.stock-input').each(function() {
                $(this).attr('disabled', true);
            });
            $('span#stock-quantity').removeClass('d-none');
            $('#offcanvas-btn').addClass('d-none');
        }

        function updateStocks(productId) {
            var formData = {};
            $('.stock-input').each(function() {
                var stockId = $(this).attr('name');
                var inputValue = $(this).val();
                formData[stockId] = inputValue;
            });

            $.ajax({
                url: "{{ route('bulk-product-stock-update') }}",
                type: "POST",
                data: {
                    _token: '{{ csrf_token() }}',
                    stocks: formData,
                    product_id: productId
                },
                success: function(response) {
                    if (response == 1) {
                        AIZ.plugins.notify('success', '{{ translate('Stock updated successfully') }}');
                        closeRightcanvas();
                    }
                },
                error: function() {
                    AIZ.plugins.notify('danger', '{{ translate('Something went wrong') }}');
                }
            });
        }

        document.addEventListener('DOMContentLoaded', () => {
            const tableTabsContainer = document.querySelector('.table-tabs-container');
            if (!tableTabsContainer) {
                return;
            }

            const tableTabs = tableTabsContainer.querySelectorAll('.nav-link');
            tableTabs.forEach(tab => {
                tab.addEventListener('click', () => {
                    const offset = tab.offsetLeft - tableTabsContainer.clientWidth / 2 + tab.clientWidth / 2;
                    tableTabsContainer.scrollTo({
                        left: offset,
                        behavior: "smooth"
                    });
                });
            });
        });
    </script>
@endsection
