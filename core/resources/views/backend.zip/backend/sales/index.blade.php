@extends('backend.layouts.app')

@section('content')
    @php
        $routeName = Route::currentRouteName();
        $pageTitle = translate('All Orders');
        $pageDescription = translate('Track fulfillment, payments, and order actions from a cleaner command view.');

        if ($routeName == 'seller_orders.index') {
            $pageTitle = translate('Seller Orders');
            $pageDescription = translate('Review marketplace orders, seller ownership, and payout-sensitive activity in one place.');
        } elseif ($routeName == 'inhouse_orders.index') {
            $pageTitle = translate('In-house Orders');
            $pageDescription = translate('Focus on in-house fulfillment performance, payment collection, and shipping progress.');
        } elseif ($routeName == 'unpaid_orders.index') {
            $pageTitle = translate('Unpaid Orders');
            $pageDescription = translate('Surface orders needing payment recovery and follow-up without losing operational context.');
        } elseif ($routeName == 'offline_payment_orders.index') {
            $pageTitle = translate('Offline Payment Orders');
            $pageDescription = translate('Review manually confirmed orders, order types, and payment follow-up status.');
        }

        $currentOrders = $orders->getCollection();
    @endphp

    <div class="admin-page-header">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <div class="admin-page-eyebrow">{{ translate('Order operations') }}</div>
                <h1 class="admin-page-title">{{ $pageTitle }}</h1>
                <p class="admin-page-description">{{ $pageDescription }}</p>
            </div>
            <div class="col-lg-4 mt-4 mt-lg-0">
                <div class="admin-header-actions">
                    <span class="admin-page-stat">
                        <span>{{ translate('Results') }}</span>
                        <strong>{{ $orders->total() }}</strong>
                    </span>
                    <span class="admin-page-stat">
                        <span>{{ translate('This page') }}</span>
                        <strong>{{ $orders->count() }}</strong>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <div class="admin-stats-grid">
        <div class="admin-stat-card">
            <div class="admin-stat-label">{{ translate('Visible orders') }}</div>
            <div class="admin-stat-value">{{ $orders->total() }}</div>
            <div class="admin-stat-meta">{{ translate('Current filtered order volume across pages.') }}</div>
        </div>
        <div class="admin-stat-card">
            <div class="admin-stat-label">{{ translate('Delivered on page') }}</div>
            <div class="admin-stat-value">{{ $currentOrders->where('delivery_status', 'delivered')->count() }}</div>
            <div class="admin-stat-meta">{{ translate('Delivered orders in the current result set.') }}</div>
        </div>
        <div class="admin-stat-card">
            <div class="admin-stat-label">{{ translate('Unpaid on page') }}</div>
            <div class="admin-stat-value">{{ $currentOrders->where('payment_status', 'unpaid')->count() }}</div>
            <div class="admin-stat-meta">{{ translate('Orders that still need payment action right now.') }}</div>
        </div>
        <div class="admin-stat-card">
            <div class="admin-stat-label">{{ translate('Fresh orders') }}</div>
            <div class="admin-stat-value">{{ $currentOrders->where('viewed', 0)->count() }}</div>
            <div class="admin-stat-meta">{{ translate('New orders that have not yet been reviewed.') }}</div>
        </div>
    </div>

    <div class="card">
        <form class="" action="" id="sort_orders" method="GET">
            <div class="card-header row gutters-5">
                <div class="col-12">
                    <div class="admin-section-intro">
                        <span class="eyebrow">{{ translate('Command view') }}</span>
                        <h2>{{ translate('Filter, review, and act on orders quickly') }}</h2>
                        <p>{{ translate('Use the compact filters below to narrow the queue, export selections, or trigger batch actions without leaving the page.') }}</p>
                    </div>
                </div>
                <div class="col-12">
                    <div class="admin-command-bar">
                        @canany(['delete_order', 'export_order'])
                            <div class="admin-command-narrow">
                                <div class="dropdown mb-0">
                                    <button class="btn btn-light dropdown-toggle w-100 justify-content-between" type="button" data-toggle="dropdown">
                                        {{ translate('Bulk Action') }}
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        @can('delete_order')
                                            <a class="dropdown-item confirm-alert" href="javascript:void(0)"  data-target="#bulk-delete-modal">{{ translate('Delete selection') }}</a>
                                        @endcan
                                        @can('export_order')
                                            <a class="dropdown-item" href="javascript:void(0)" onclick="order_bulk_export()">{{ translate('Export') }}</a>
                                        @endcan
                                        @if(auth()->user()->can('unpaid_order_payment_notification_send') && $unpaid_order_payment_notification->status == 1 && Route::currentRouteName() == 'unpaid_orders.index')
                                            <a class="dropdown-item" href="javascript:void(0)" onclick="bulk_unpaid_order_payment_notification()">{{ translate('Unpaid Order Payment Notification') }}</a>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        @endcanany

                        @if(Route::currentRouteName() == 'offline_payment_orders.index')
                            <div class="admin-command-narrow">
                                <select class="form-control aiz-selectpicker" name="order_type" id="order_type">
                                    <option value="">{{ translate('Filter by Order Type') }}</option>
                                    <option value="inhouse_orders" @if ($order_type == 'inhouse_orders') selected @endif>{{ translate('Inhouse Orders') }}</option>
                                    <option value="seller_orders" @if ($order_type == 'seller_orders') selected @endif>{{ translate('Seller Orders') }}</option>
                                </select>
                            </div>
                        @endif

                        <div class="admin-command-narrow">
                            <select class="form-control aiz-selectpicker" name="delivery_status" id="delivery_status">
                                <option value="">{{ translate('Filter by Delivery Status') }}</option>
                                <option value="pending" @if ($delivery_status == 'pending') selected @endif>{{ translate('Pending') }}</option>
                                <option value="confirmed" @if ($delivery_status == 'confirmed') selected @endif>{{ translate('Confirmed') }}</option>
                                <option value="picked_up" @if ($delivery_status == 'picked_up') selected @endif>{{ translate('Picked Up') }}</option>
                                <option value="on_the_way" @if ($delivery_status == 'on_the_way') selected @endif>{{ translate('On The Way') }}</option>
                                <option value="delivered" @if ($delivery_status == 'delivered') selected @endif>{{ translate('Delivered') }}</option>
                                <option value="cancelled" @if ($delivery_status == 'cancelled') selected @endif>{{ translate('Cancel') }}</option>
                            </select>
                        </div>

                        @if(Route::currentRouteName() != 'unpaid_orders.index')
                            <div class="admin-command-narrow">
                                <select class="form-control aiz-selectpicker" name="payment_status" id="payment_status">
                                    <option value="">{{ translate('Filter by Payment Status') }}</option>
                                    <option value="paid" @isset($payment_status) @if ($payment_status == 'paid') selected @endif @endisset>{{ translate('Paid') }}</option>
                                    <option value="unpaid" @isset($payment_status) @if ($payment_status == 'unpaid') selected @endif @endisset>{{ translate('Unpaid') }}</option>
                                </select>
                            </div>
                        @endif

                        <div class="admin-command-narrow">
                            <input type="text" class="aiz-date-range form-control" value="{{ $date }}" name="date"
                                placeholder="{{ translate('Filter by date') }}" data-format="DD-MM-Y"
                                data-separator=" to " data-advanced-range="true" autocomplete="off">
                        </div>

                        <div class="admin-command-grow">
                            <input type="text" class="form-control" id="search"
                                name="search"@isset($sort_search) value="{{ $sort_search }}" @endisset
                                placeholder="{{ translate('Type order code and hit Enter') }}">
                        </div>

                        <div class="admin-command-narrow">
                            <button type="submit" class="btn btn-primary w-100">{{ translate('Apply Filters') }}</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <table class="table aiz-table mb-0">
                    <thead>
                        <tr>
                            @if (auth()->user()->can('delete_order') || auth()->user()->can('export_order'))
                                <th>
                                    <div class="form-group">
                                        <div class="aiz-checkbox-inline">
                                            <label class="aiz-checkbox">
                                                <input type="checkbox" class="check-all">
                                                <span class="aiz-square-check"></span>
                                            </label>
                                        </div>
                                    </div>
                                </th>
                            @else
                                <th data-breakpoints="lg">#</th>
                            @endif

                            <th>{{ translate('Order Code') }}</th>
                            <th data-breakpoints="md">{{ translate('Num. of Products') }}</th>
                            <th data-breakpoints="md">{{ translate('Customer') }}</th>
                            <th data-breakpoints="md">{{ translate('Seller') }}</th>
                            <th data-breakpoints="md">{{ translate('Amount') }}</th>
                            <th data-breakpoints="md">{{ translate('Delivery Status') }}</th>
                            <th data-breakpoints="md">{{ translate('Payment method') }}</th>
                            <th data-breakpoints="md">{{ translate('Payment Status') }}</th>
                            @if (addon_is_activated('refund_request'))
                                <th>{{ translate('Refund') }}</th>
                            @endif
                            <th class="text-right" width="15%">{{ translate('options') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($orders as $key => $order)
                            <tr>
                                @if (auth()->user()->can('delete_order') || auth()->user()->can('export_order'))
                                    <td>
                                        <div class="form-group">
                                            <div class="aiz-checkbox-inline">
                                                <label class="aiz-checkbox">
                                                    <input type="checkbox" class="check-one" name="id[]"
                                                        value="{{ $order->id }}">
                                                    <span class="aiz-square-check"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </td>
                                @else
                                    <td>{{ $key + 1 + ($orders->currentPage() - 1) * $orders->perPage() }}</td>
                                @endif
                                <td>
                                    {{ $order->code }}
                                    @if ($order->shipping_method == 'shiprocket')
                                        <br><span class="fw-bold">{{ translate('Shiprocket Order Id') }}:</span> {{ $order->shiprocket_order_id }}
                                    @endif
                                    @if ($order->shipping_method == 'steadfast')
                                        <br><span class="fw-bold">{{ translate('Steadfast Consignment Id') }}:</span> {{ $order->steadfast_consignment_id }}
                                    @endif
                                    @if ($order->shipping_method == 'pathao')
                                        <br><span class="fw-bold">{{ translate('Pathao Consignment Id') }}:</span> {{ $order->pathao_consignment_id }}
                                    @endif
                                    @if ($order->viewed == 0)
                                        <span class="badge badge-inline badge-info">{{ translate('New') }}</span>
                                    @endif
                                    @if (addon_is_activated('pos_system') && $order->order_from == 'pos')
                                        <span class="badge badge-inline badge-danger">{{ translate('POS') }}</span>
                                    @endif
                                </td>
                                <td>
                                    {{ count($order->orderDetails) }}
                                </td>
                                <td>
                                    @if ($order->user != null)
                                        {{ $order->user->name }}
                                    @else
                                        Guest ({{ $order->guest_id }})
                                    @endif
                                </td>
                                <td>
                                    @if ($order->shop)
                                        {{ $order->shop->name }}
                                    @else
                                        {{ translate('Inhouse Order') }}
                                    @endif
                                </td>
                                <td>
                                    {{ single_price($order->grand_total) }}
                                </td>
                                <td>
                                    {{ translate(ucfirst(str_replace('_', ' ', $order->delivery_status))) }} <br>
                                    @if ($order->shipping_method == 'shiprocket')
                                        <span class="fw-bold">{{ translate('Shiprocket Status') }}:</span> {{ ucfirst(translate(str_replace('_', ' ', $order->shiprocket_status))) }}
                                    @endif
                                    @if ($order->shipping_method == 'steadfast')
                                        <span class="fw-bold">{{ translate('Steadfast Status') }}:</span> {{ ucfirst(translate(str_replace('_', ' ', $order->steadfast_status))) }}
                                    @endif
                                    @if ($order->shipping_method == 'pathao')
                                        <span class="fw-bold">{{ translate('Pathao Status') }}:</span> {{ ucfirst(translate(str_replace('_', ' ', $order->pathao_status))) }}
                                    @endif
                                </td>
                                <td>
                                    {{ translate(ucfirst(str_replace('_', ' ', $order->payment_type))) }}
                                </td>
                                <td>
                                    @if ($order->payment_status == 'paid')
                                        <span class="badge badge-inline badge-success">{{ translate('Paid') }}</span>
                                    @else
                                        <span class="badge badge-inline badge-danger">{{ translate('Unpaid') }}</span>
                                    @endif
                                </td>
                                @if (addon_is_activated('refund_request'))
                                    <td>
                                        @if (count($order->refund_requests) > 0)
                                            {{ count($order->refund_requests) }} {{ translate('Refund') }}
                                        @else
                                            {{ translate('No Refund') }}
                                        @endif
                                    </td>
                                @endif
                                <td class="text-right">
                                    @if (addon_is_activated('pos_system') && $order->order_from == 'pos')
                                        <a class="btn btn-soft-success btn-icon btn-circle btn-sm"
                                            href="{{ route('admin.invoice.thermal_printer', $order->id) }}" target="_blank"
                                            title="{{ translate('Thermal Printer') }}">
                                            <i class="las la-print"></i>
                                        </a>
                                    @endif
                                    @can('view_order_details')
                                        @php
                                            $order_detail_route = route('all_orders.show', encrypt($order->id));
                                            if (Route::currentRouteName() == 'seller_orders.index') {
                                                $order_detail_route = route('seller_orders.show', encrypt($order->id));
                                            } elseif (Route::currentRouteName() == 'pick_up_point.index') {
                                                $order_detail_route = route('pick_up_point.order_show', encrypt($order->id));
                                            }
                                            if (Route::currentRouteName() == 'inhouse_orders.index') {
                                                $order_detail_route = route('inhouse_orders.show', encrypt($order->id));
                                            }
                                        @endphp
                                        <a class="btn btn-soft-primary btn-icon btn-circle btn-sm"
                                            href="{{ $order_detail_route }}" title="{{ translate('View') }}">
                                            <i class="las la-eye"></i>
                                        </a>
                                    @endcan
                                    <a class="btn btn-soft-info btn-icon btn-circle btn-sm"
                                        href="{{ route('invoice.download', $order->id) }}"
                                        title="{{ translate('Download Invoice') }}">
                                        <i class="las la-download"></i>
                                    </a>
                                    @if(auth()->user()->can('unpaid_order_payment_notification_send') && $order->payment_status == 'unpaid' && $unpaid_order_payment_notification->status == 1)
                                        <a class="btn btn-soft-warning btn-icon btn-circle btn-sm"
                                            href="javascript:void();" onclick="unpaid_order_payment_notification('{{ $order->id }}');"
                                            title="{{ translate('Unpaid Order Payment Notification') }}">
                                            <i class="las la-bell"></i>
                                        </a>
                                    @endif
                                    @can('delete_order')
                                        <a href="#"
                                            class="btn btn-soft-danger btn-icon btn-circle btn-sm confirm-delete"
                                            data-href="{{ route('orders.destroy', $order->id) }}"
                                            title="{{ translate('Delete') }}">
                                            <i class="las la-trash"></i>
                                        </a>
                                    @endcan
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>

                <div class="aiz-pagination">
                    {{ $orders->appends(request()->input())->links() }}
                </div>

            </div>
        </form>
    </div>
@endsection

@section('modal')
    <!-- Delete modal -->
    @include('modals.delete_modal')

    <!-- Bulk Delete modal -->
    @include('modals.bulk_delete_modal')

    {{-- Bulk Unpaid Order Payment Notification --}}
    <div id="complete_unpaid_order_payment" class="modal fade">
        <div class="modal-dialog modal-md modal-dialog-centered" style="max-width: 540px;">
            <div class="modal-content pb-2rem px-2rem">
                <div class="modal-header border-0">
                    <button type="button" class="close" data-dismiss="modal"></button>
                </div>
                <form class="form-horizontal" action="{{ route('unpaid_order_payment_notification') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body text-center">
                        <input type="hidden" name="order_ids" value="" id="order_ids">
                        <p class="mt-2 mb-2 fs-16 fw-700">{{ translate('Are you sure to send notification for the selected orders?') }}</p>
                        <button type="submit" class="btn btn-warning rounded-2 mt-2 fs-13 fw-700 w-250px">{{ translate('Send Notification') }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

@endsection

@section('script')
    <script type="text/javascript">
        $(document).on("change", ".check-all", function() {
            if (this.checked) {
                // Iterate each checkbox
                $('.check-one:checkbox').each(function() {
                    this.checked = true;
                });
            } else {
                $('.check-one:checkbox').each(function() {
                    this.checked = false;
                });
            }

        });

        function sort_orders(el){
            $('#sort_orders').submit();
        }

        function bulk_delete() {
            var data = new FormData($('#sort_orders')[0]);
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: "{{ route('bulk-order-delete') }}",
                type: 'POST',
                data: data,
                cache: false,
                contentType: false,
                processData: false,
                success: function(response) {
                    if (response == 1) {
                        AIZ.plugins.notify('success', 'Selected items deleted successfully');
                        location.reload();
                    }
                }
            });
        }
        
        function order_bulk_export (){
            var url = '{{route('order-bulk-export')}}';
            $("#sort_orders").attr("action", url);
            $('#sort_orders').submit();
            $("#sort_orders").attr("action", '');
        }

        // Unpaid Order Payment Notification
        function unpaid_order_payment_notification(order_id){
            var orderIds = [];
            orderIds.push(order_id);
            $('#order_ids').val(orderIds);
            $('#complete_unpaid_order_payment').modal('show', {backdrop: 'static'});
        }

        // Unpaid Order Payment Notification
        function bulk_unpaid_order_payment_notification(){
            var orderIds = [];
            $(".check-one[name='id[]']:checked").each(function() {
                orderIds.push($(this).val());
            });
            if(orderIds.length > 0){
                $('#order_ids').val(orderIds);
                $('#complete_unpaid_order_payment').modal('show', {backdrop: 'static'});
            }
            else{
                AIZ.plugins.notify('danger', '{{ translate('Please Select Order first.') }}');
            }
        }
    </script>
@endsection
